﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SapXepBasic
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int[] DanhSachPhanTu;
        Random r = new Random();

        private void btnTao_Click(object sender, RoutedEventArgs e)
        {
            int sophantu = int.Parse(txtSoPhanTu.Text);
            DanhSachPhanTu = new int[sophantu];
            for (int i = 0; i < sophantu; i++)
            {
                DanhSachPhanTu[i] = r.Next(100);
                HienThiMang(DanhSachPhanTu, lblMangDuocTao);
            }
        }
        void HienThiMang(int[] DanhSachPhanTu, Label lblMangDuocTao)
        {
            
            lblMangDuocTao.Content = "";
            //tiến hành hiển thị lại dữ liệu mới:
            for (int i = 0; i < DanhSachPhanTu.Length; i++)
            {
                lblMangDuocTao.Content += DanhSachPhanTu[i] + " ; ";
            }
        }

        private void btnBubble_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < DanhSachPhanTu.Length; i++)
            {
                for (int j = DanhSachPhanTu.Length - 1; j > i; j--)
                {
                    if (DanhSachPhanTu[j] < DanhSachPhanTu[j - 1])
                    {
                        int tmp = DanhSachPhanTu[j];
                        DanhSachPhanTu[j] = DanhSachPhanTu[j - 1];
                        DanhSachPhanTu[j - 1] = tmp;
                    }
                }
                HienThiMang(DanhSachPhanTu, lblKetQuaSapXep);
            }
        }

        private void btnSelection_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < DanhSachPhanTu.Length; i++)
            {
                int min = i;
                for (int j = i + 1; j < DanhSachPhanTu.Length; j++)
                {
                    if (DanhSachPhanTu[j] < DanhSachPhanTu[min])
                    {
                        int tmp = DanhSachPhanTu[min];
                        DanhSachPhanTu[min] = DanhSachPhanTu[i];
                        DanhSachPhanTu[i] = tmp;
                    }
                }
                HienThiMang(DanhSachPhanTu, lblKetQuaSapXep);
            }

        }

        private void btnIntercharge_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < DanhSachPhanTu.Length; i++)
            {
                for (int j = i + 1; j < DanhSachPhanTu.Length; j++)
                {
                    if (DanhSachPhanTu[i] < DanhSachPhanTu[j])
                    {
                        int tmp = DanhSachPhanTu[i];
                        DanhSachPhanTu[i] = DanhSachPhanTu[j];
                        DanhSachPhanTu[j] = tmp;
                    }
                }
                HienThiMang(DanhSachPhanTu, lblKetQuaSapXep);
            }
        }
       void QuickSort(int [] DanhSachPhanSo,int l, int r)
        {
            {
                int tmp;
                int i = l;
                int j = r;
                int pivot = DanhSachPhanSo[r - 1];
                while(i<j)
                {
                    while (DanhSachPhanSo[i] < pivot) i++;
                    while (DanhSachPhanSo[j] < pivot) j--;
                    if(i<=j)
                    {
                        tmp = DanhSachPhanTu[i];
                        DanhSachPhanTu[i] = DanhSachPhanTu[j];
                        DanhSachPhanTu[j] = tmp;
                        i++;
                        j--;
                    }

                }
                if (l < i) QuickSort(DanhSachPhanSo, l, j);
                if (i<r) QuickSort(DanhSachPhanSo, i,r);
            }
        }

        private void btnQuick_Click(object sender, RoutedEventArgs e)
        {
            int sophantu = int.Parse(txtSoPhanTu.Text);
            QuickSort(DanhSachPhanTu,0, sophantu-1);
            HienThiMang(DanhSachPhanTu, lblKetQuaSapXep);
        }

        
    }
}

